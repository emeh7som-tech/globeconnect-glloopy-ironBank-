Glloopy + IronBank (merged) - scaffold
=====================================

O que foi criado:
- /public : arquivos do site (index.html, style.css, w.js, k.js, painel.js)
- /keys   : chave pública RSA encontrada (se presente)
- /server : scaffold Node.js/Express com endpoints de exemplo
- package.json

Próximos passos (manuais que você pode executar):
1) Rever e ajustar `public/index.html` para ligar o painel secreto apenas a usuários autenticados.
2) Configurar variáveis de ambiente antes do deploy:
   - KILL_SWITCH_SECRET (valor secreto do kill-switch)
   - NODE_ENV=production
3) Para deploy no Vercel:
   - Vercel serve projetos Node.js; apenas suba este diretório como um projeto.
   - Configure build command (não necessário aqui) e defina variáveis de ambiente.
4) Para integrar com Supabase (login, DB):
   - Crie um projeto Supabase e copie as chaves (ANON/Service Role) em variáveis de ambiente.
   - Adicione rotas no server/server.js que usam @supabase/supabase-js.
5) Para gerar APK Android:
   - Recomendo transformar a pasta `public` em um webview app (React Native / Capacitor / Cordova).
   - Arquivos Android nativos não foram gerados aqui; posso ajudar com um template Capacitor se desejar.
6) Segurança crítica:
   - Não exponha a chave privada no repositório.
   - Atualize o kill-switch para usar JWT ou OAuth para autenticação forte.
   - Implemente rate limiting e logging seguro.

Arquivos importantes:
- public/index.html
- public/style.css
- public/painel.js
- public/k.js
- public/w.js
- keys/chave_publica_RSA.pem (se presente)
- server/server.js
- package.json

Observações:
- Não realizei build nem deploy automático (precisa de permissões/contas externas).
- Se quiser, posso:
   a) Gerar um template Capacitor para Android e subir um .zip do APK-ready.
   b) Implementar login com Supabase neste scaffold.
   c) Reforçar a segurança do kill-switch (server-side + audit logs).
