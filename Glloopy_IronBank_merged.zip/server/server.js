// server.js - minimal Express scaffold for Glloopy + IronBank
const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Healthcheck
app.get('/health', (req, res) => res.json({status: 'ok', project: 'Glloopy_IronBank'}));

// Placeholder: protected kill-switch endpoint (requires AUTH in env)
app.post('/api/kill-switch', (req, res) => {
    const secret = process.env.KILL_SWITCH_SECRET || 'CHAVE-SECRETA-123';
    if (req.body && req.body.key === secret) {
        // In a real deployment, implement server-side actions here.
        return res.json({status: 'killed'});
    }
    return res.status(401).json({error: 'unauthorized'});
});

// Placeholder RSA verify endpoint (example)
app.get('/api/public-key', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'keys', 'chave_publica_RSA.pem'));
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
